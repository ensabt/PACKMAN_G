#include "projectpackman.h"

int login()
{
    char username[constant], password[constant];
    int i, creat , cmd;
    printf("welcome the pack man game!\n");
    printf("pleaw enter a username and passwoed\n");
    scanf("%s%s" , username , password);
    printf("HELLO %s!\n" ,username);
    for(i= 0 ; i < users_num ;++i)
    {
        if(strcmp(player[i].gamername , username)==0 && strcmp(player[i].password , password)==0 && player[i].is_valid == 1)
        {
            printf("Do you want to delete your account? Enter 1 to delete your account, or 0 otherwise.");
            scanf("%d" , &cmd);
            if(cmd == 1)
            {
                delete_account(i);
            }
            else
                return i;
        }
    }
    if( i ==users_num)
    {
        printf("The user with these credentials does not exist! Please create an account.\n");
        printf ("To create an account, enter 1; otherwise, enter 0.\n");
        scanf("%d", &creat);
        while(true)
        {
            if(creat == 1)
            {
                creat_account(username , password);
                break;
            }
            else if (creat == 0)
            {
                exit(0);
            }
            else
            {
                printf("The entered number is not valid.\n");
            }
        }
    }
}
void  delete_account(int i)
{
    player[i].is_valid = false;
}
void Read_fromfile()
{ 
    int i =0 , j;
    FILE * userinfo;
    userinfo = fopen("F:\\usersfile.txt","r");
    if(userinfo != NULL) // خواندن اطلاعات بازیکن ها
    {
        for(i=0 ; i <users_num ; ++i)
        {
            fscanf(userinfo , "%s\n%s\n%s\n%d\n%d\n%d\n%d\n%d\n%d\n" ,player[i].Filename , player[i].gamername , player[i].password , &player[i].id , &player[i].level , &player[i].score ,&player[i].is_valid , &player[i].Status, &player[i].difmap);

        }
        fclose(userinfo);
    }
}
int creat_account(char username[constant] , char password [constant])
{
    int i , id , m , temp =0;
    for(i =0 ; i< users_num ;++i)
    {
        if(player[i].is_valid == 0)
        {
            while(true)
            {
                printf("Please enter your ID,The ID must be 8 characters long.\n");
                scanf("%d" ,&id);
                temp = id;
                for( m = 0 ; temp != 0 ; ++m)
                {
                    temp =temp /10;
                }
                if( m == 8)
                {
                    player[i].id = id;
                    break;
                }
                else
                {
                     printf("The entered ID is not valid!");
                }
            }
            temp = id;
            for( int z=7 ; z>=0 ;--z)
            {
                player[i].Filename[z] = temp % 10 +'0';
                temp = temp /10;
            }
            player[i].Filename[8] ='.';
            player[i].Filename[9] = 't';
            player[i].Filename[10] ='x';
            player[i].Filename[11] = 't';
            strcpy(player[i].gamername , username);
            strcpy(player[i].password , password);
            player[i].is_valid = 1;
            player[i].level = 0;
            player[i].score = 0;
            player[i].Status =0; // yani barai bazi niaz b file nist
            return i;
        }
    }
}
void Save_playerdata(int Counter)
{
    FILE * userinfo;
    userinfo = fopen("F:\\usersfile.txt","w"); // در فایل مشخصات بازیکن ها وجود دراد usrefile. ا
    int i =0;
    for(i=0 ; i<users_num && player[i].is_valid == 1 ;++i)
    {
        fprintf(userinfo , "%s\n%s\n%s\n%d\n%d\n%d\n%d\n%d\n%d\n" , player[i].Filename , player[i].gamername , player[i].password , player[i].id , player[i].level , player[i].score ,player[i].is_valid , player[i].Status , player[i].difmap);
    }
    fclose(userinfo);
}
void setup(int gametype , int Counter)
{
    int i , j , n=0 , m=0;
    dir = STOP;
    switch (gametype)
    {
    case 1:
        n = 10;
        m = 11;
        player[Counter].difmap = 1;
        break;
    case 2:
        n = 8;
        m = 10;
        player[Counter].difmap = 2;
        break;
    case 3:
        n = 5;
        m = 8;
        player[Counter].difmap = 3;
        break;
    default:
        break;
    }
    map = (char**)malloc(n * sizeof(char*));
    for(i=0 ; i< n ; ++i)
    {
        map[i] = (char*)malloc(sizeof (char));
    }
    for (i = 0; i < ghost_max; ++i)
    {
        location.ghost[i].is_valid = 0;
    }
    for(i=0 ;i <n ;++i)
    {
        for(j=0 ;j <m ;++j)
        {
            map [i][j]=0; 
        }
    }
    
}
char** big_map( int command)
{
    char pack_man[4][6] = {
        { ' ', '.', '-', '-', '.', ' ' },
        { '/', ' ', '_', '.', '-', '`' },
        { '\\', ' ', ' ', ' ', '`', '.' },
        { ' ', '`', '-', '-', '`', ' ' }
    };
    char pill[4][6] = {
        { ' ', ' ', ' ', ' ', ' ', ' ' },
        { ' ', '.', '-', '.', ' ', ' ' },
        { ' ', '`', '_', '`', ' ', ' ' },
        { ' ', ' ', ' ', ' ', ' ', ' ' }
    };
    char ghost[4][6] = {
    { ' ', '.', '-', '-', '.', ' ' },
    { '|', ' ', 'O', 'O', ' ', '|' },
    { '|', ' ', ' ', ' ', ' ', '|' },
    { '.', '^', '^', '^', '^', '.' }
};

    int n , m, i, j , k , l;
    int f , row , col;
    switch (command)
    {
    case 1:
        n =10;
        m = 11;
        break;
    case 2:
        n =8;
        m =10;
        break;
    case 3:
        n = 5;
        m =8;
        break;
    default:
        break;
    }
     if (mapB != NULL) 
     {
        for (i = 0; i < n * 4; ++i) 
        {
            free(mapB[i]);
        }
        free(mapB);
    }
    mapB = (char**)malloc(n * 4 * sizeof(char*));
    for (i = 0; i < n * 4; ++i) 
    {
        mapB[i] = (char*)malloc(m * 6 * sizeof(char));
    }
    for (i = 0; i < n * 4; ++i) 
    {
        for (j = 0; j < m * 6; ++j) 
        {
            mapB[i][j] = ' '; // مقداردهی اولیه به تمام خانه‌های mapB
        }
    }
    for(i=0 ; i< n ;++i)
    {
        for(j =0 ;j<m ;++j)
        {
            switch (map[i][j])
            {
            case '|':
            case '-':
                for(k= i*4; k<4*i+4 ; k++)
                {
                    for(l=j*6; l<6*j+6; l++)
                    {
                        mapB[k][l] = '#'; // دیوار
                    }
                }
            break;
            case '.':
            for(k = i * 4; k < 4 * i + 4; k++) 
            {
                for(l = j * 6; l < 6 * j + 6; l++) 
                {
                    mapB[k][l] = ' '; // خالی کردن فضای نقطه
                }
            }
            break;
            case '@':
                k = i*4;
                l =  j*6;;
                for (row = 0; row < 4; ++row) 
                {
                    for (col = 0; col < 6; ++col) 
                    {
                        mapB[k + row][l + col] = pack_man[row][col];
                    }
                }
                break;
            case 'P':
                k = i * 4;
                l = j * 6;
                for (row = 0; row < 4; ++row) {
                    for (col = 0; col < 6; ++col) {
                        mapB[k + row][l + col] = pill[row][col];
                    }
                }
                break;
            case 'G':
                k = i * 4;
                l = j * 6;
                for (row = 0; row < 4; ++row) 
                {
                    for (col = 0; col < 6; ++col) 
                    {
                        mapB[k + row][l + col] = ghost[row][col];
                    }
                }
                break;
            default:
            for(k = i * 4; k < 4 * i + 4; k++) {
                for(l = j * 6; l < 6 * j + 6; l++) {
                    mapB[k][l] = ' '; // خالی کردن فضای نقطه برای مقادیر نامشخص
                }
            }
            break;
            }
        }
    }
    return mapB;
}

void draw(int gametype , int Counter)
{
    system("cls");

    int i,n=0 , temp , m=0 , j;
    FILE* mapFile;
    char tmp [20];

    switch (gametype)
    {
    case 1:
        mapFile = fopen("F:\\hard.txt", "r");
        n = 10;
        m = 11;
        player[Counter].difmap = 1;
        strcpy(tmp , "hard");
        break;
    case 2:
        mapFile = fopen("F:\\intermediate","r");
        n = 8;
        m = 10;
        player[Counter].difmap = 2;
        strcpy(tmp , "intermediate");
        break;
    case 3:
        mapFile = fopen("F:\\easy.txt", "r");
        n = 5;
        m = 8;
        player[Counter].difmap = 3;
        strcpy(tmp , "easy");
        break;
    default:
        printf("The entered number is not valid.\n");
        return;
    }
    if(player[Counter].Status == 1)
    {
        if(player[Counter].difmap == gametype)
        {
            printf("Do you want to resume the previous game? Enter 1 to continue, or 0 otherwise.");
            scanf("%d", &temp);
            if(temp == 1)
            {
                mapFile = fopen(player[Counter].Filename , "r");
            }
        }
        
    }
    else
    {
        player[Counter].score = 0;
    }
    for (i = 0; i < n; ++i)
    {
        fgets(map[i], constant, mapFile);
    }
    mapB = big_map(gametype);

    for (i = 0; i < n*4; ++i)
    {
        for(j =0 ; j< m*6 ;++ j)
        {
            printf("%c" , mapB[i][j]);
        }
        printf("\n");
    }
    if (mapFile == NULL)
    {
        printf("Error opening the map file.\n");
        exit (0);
        return;
    }
    fclose(mapFile);

    printf("playername; %s\n", player[Counter].gamername);
    printf("%smap\n" , tmp);
    printf("score:%d\n", player[Counter].score);
    printf("To finish the game, press the E key.\n");
}
void draw1(int gametype , int Counter)
{
    system("cls");

    int size, i, j ,n , m;
    char tmp[20];
    FILE* mapFile;

    switch (gametype)
    {
    case 1:
       n = 10;
       m = 11;
       strcpy(tmp , "hard");
        break;
    case 2:
        n = 8;
        m = 10;
        strcpy(tmp , "intermediate");
        break;
    case 3:
        n = 5;
        m = 8;
        strcpy(tmp , "easy");
        break;
    default:
        printf("The entered number is not valid.\n");
        return;
    }
    for (i = 0; i < n *4; ++i)
    {
        for(j =0 ; j<m*6 ;++j)
        {
            printf("%c", mapB[i][j]);
        }
        printf("\n");
    }
    printf("playername; %s\n", player[Counter].gamername);
    printf("%smap\n" , tmp);
    printf("score:%d\n", player[Counter].score);
    printf("To finish the game, press the E key.\n");
}


void input()
{
    while (! _kbhit())
    {
        switch (getch())
        {
        case 'W':
        case 'w':
            dir = UP;
            break;
        case 'S':
        case 's':
            dir = DOWN;
            break;
        case 'A':
        case 'a':
            dir = LEFT;
            break;
        case 'D':
        case 'd':
            dir = RIGHT;
            break;
        case 'E':
        case 'e':
            dir = EXIT;
            break;
        default:
            break;
        }
        break;
    }
}


void logic(int command, int Counter)
{
    FILE * usermap;
    int i, j , m =0 ,n,flag =0,l= 0;
    int x , f , k , cmd,y;
    j = location.packman.x;
    i = location.packman.y;
    switch (dir)
    {
    case LEFT:
        if (map[i][j - 1] == '.')
        {
            map[i][j-1] ='@';
            map[i][j] = '.';
           
        }
        if (map[i][j-1] == 'P')
        {
            player[Counter].score += 10;
            if(command == 1)
            {
                if(player[Counter].score == 30)
                {
                    player[Counter].level +=3;
                    player[Counter].Status = 0;
                    Save_playerdata(Counter); 
                    printf("You Win!\n");
                    exit(0);
                }
                else
                {
                    map[i][j-1] = '@';
                     map[i][j] = '.';
                     BEEP(750, 800);
                }
            }
            else if (command == 2)
            {
                if(player[Counter].score == 20)
                {
                    player[Counter].level +=3;
                    player[Counter].Status = 0;
                    Save_playerdata(Counter); 
                    printf("You Win!\n");
                    exit(0);
                }
                else
                {
                    map[i][j-1] = '@';
                     map[i][j] = '.';
                     BEEP(750, 800);
                }
            }
            else if (command == 3)
            {
                if(player[Counter].score == 10)
                {
                    player[Counter].level +=3;
                    player[Counter].Status = 0;
                    Save_playerdata(Counter); 
                    printf("You Win!\n");
                    exit(0);
                }
                else
                {
                    map[i][j-1] = '@';
                     map[i][j] = '.';
                     BEEP(750, 800);
                }
            }
        }
        if (map[i][j-1] == 'G')
        {
            n =location.packman.x;
            m = location.packman.y ;
            map[i][j] ='G';
            map[i][j-1] = '.';
            player[Counter].level -=1;
            player[Counter].Status = 0;
            Save_playerdata(Counter); 
            printf("You lost.!\n");
            exit(0);
        } 
        location.packman.x = j-1;
        location.packman.y = i;
        break;

    case RIGHT:
        if (map[i][j + 1] == '.')
        {
            map [i][j+1] = '@';
            map [i][j] = '.';
        }
        if (map[i][j+1] == 'P')
        {
            player[Counter].score += 10;
            if(command == 1)
            {
                if(player[Counter].score == 30)
                {
                    player[Counter].level+=3;
                    player[Counter].Status = 0;
                    Save_playerdata(Counter); 
                    printf("You Win!\n");
                    exit(0);
                }
                else
                {
                    map[i][j+1] = '@';
                     map[i][j] = '.';
                     BEEP(750, 800);
                }
            }
            else if (command == 2)
            {
                if(player[Counter].score += 20)
                {
                    player[Counter].level+=3;
                    player[Counter].Status = 0;
                    Save_playerdata(Counter); 
                    printf("You Win!\n");
                    exit(0);
                }
                else
                {
                    map[i][j+1] = '@';
                     map[i][j] = '.';
                     BEEP(750, 800);
                }
            }
            else if (command == 3)
            {
                if(player[Counter].score += 10)
                {
                    player[Counter].level+=3;
                    player[Counter].Status = 0;
                    Save_playerdata(Counter); 
                    printf("You Win!\n");
                    exit(0);
                }
                else
                {
                    map[i][j+1] = '@';
                     map[i][j] = '.';
                     BEEP(750, 800);
                }
            }
        }
        if (map[i][j+1] == 'G')
        {
            n =location.packman.x;
            m = location.packman.y ;
            map[i][j] ='G';
            map[i][j+1] = '.';
            player[Counter].level -= 1;
            player[Counter].Status = 0;
            Save_playerdata(Counter); 
            printf("You lost.!\n");
            exit(0);
        }
        location.packman.x = j+1;
        location.packman.y = i;
        break;
        
    case UP:
        if (map[i - 1][j] == '.')
        {
            map[i-1][j] = '@';
            map [i][j] = '.';
        }
        if (map[i-1][j] == 'P')
        {
            player[Counter].score += 10;
            if(command == 1)
            {
                if(player[Counter].score == 30)
                {
                    player[Counter].level+=3;
                    player[Counter].Status = 0;
                    Save_playerdata(Counter); 
                    printf("You Win!\n");
                    exit(0);
                }
                else
                {
                    map[i-1][j] = '@';
                     map[i][j] = '.';
                     BEEP(750, 800);
                }
            }
            else if (command == 2)
            {
                if(player[Counter].score += 20)
                {
                    player[Counter].level+=3;
                    player[Counter].Status = 0;
                    Save_playerdata(Counter); 
                    printf("You Win!\n");
                    exit(0);
                }
                else
                {
                    map[i-1][j] = '@';
                     map[i][j] = '.';
                     BEEP(750, 800);
                }
            }
            else if (command == 3)
            {
                if(player[Counter].score += 10)
                {
                    player[Counter].level+=3;
                    player[Counter].Status = 0;
                    Save_playerdata(Counter); 
                    printf("You Win!\n");
                    exit(0);
                }
                else
                {
                    map[i-1][j] = '@';
                     map[i][j] = '.';
                     BEEP(750, 800);
                }
            }
            
        }

        if (map[i-1][j] == 'G')
        {
            n =location.packman.x;
            m = location.packman.y ;
            map[i][j] ='G';
            map[i-1][j] = '.';
            player[Counter].level -= 1;
            player[Counter].Status = 0;
            Save_playerdata(Counter); 
            printf("You lost.!\n");
            exit(0);   
        } 
        location.packman.x = j;
        location.packman.y = i -1;
        break;
    case DOWN:
        if (map[i + 1][j] == '.')
        {
            map[i+1][j] = '@';
            map[i][j] = '.';
        }
        if (map[i+1][j] == 'P')
        {
            player[Counter].score += 10;
            if(command == 1)
            {
                if(player[Counter].score == 30)
                {
                    player[Counter].level+=3;
                    player[Counter].Status = 0;
                    Save_playerdata(Counter); 
                    printf("You Win!\n");
                    exit(0);
                }
                else
                {
                    map[i+1][j] = '@';
                    map[i][j] = '.';
                    
                }
            }
            else if (command == 2)
            {
                if(player[Counter].score == 20)
                {
                    player[Counter].level+=3;
                    player[Counter].Status = 0;
                    Save_playerdata(Counter); 
                    printf("You Win!\n");
                    exit(0);
                }
                else
                {
                    map[i+1][j] = '@';
                     map[i][j] = '.';
                }
            }
            else if (command == 3)
            {
                if(player[Counter].score == 10)
                {
                    player[Counter].level+=3;
                    player[Counter].Status = 0;
                    Save_playerdata(Counter); 
                    printf("You Win!\n");
                    exit(0);
                }
                else
                {
                    map[i+1][j] = '@';
                     map[i][j] = '.';
                }
            }
            
        }
        if (map[i+1][j] == 'G')
        {

            n =location.packman.x;
            m = location.packman.y ;
            map[i][j] ='G';
            map[i+1][j] = '.';
            player[Counter].level -= 1;
            player[Counter].Status = 0;
            Save_playerdata(Counter); 
            printf("You lost.!\n");
            exit(0);
        }
        location.packman.x = j;
        location.packman.y = i +1;
         break;

    case EXIT:
        switch (command)
        {
        case 1:
            k = 10;
            break;
        case 2:
            k = 8;
            break;
        case 3:
            k = 5;
            break;    
        default:
            break;
        }
        printf("Would you like to save the current game?Please enter 1 to save the game, otherwise enter 0.\n");
        scanf("%d" , &cmd);
        if(cmd == 1)
        {
            usermap = fopen(player[Counter].Filename , "w+");
            if(usermap == NULL)
            {
                printf("The file doesn't open.\n");
            }
            for( int p =0 ; p < k ; ++p)
            {
                fprintf(usermap ,"%s" ,map[p]);
            }
            player[Counter].Status = 1;
            Save_playerdata(Counter); 
            exit(0);
        }
        else if(cmd == 0)
        {
            Save_playerdata(Counter);
            exit(0); 
        }
       

    default:
        break;
    }
}


void find(int command)
{
    int i, j, z = 0 , m ,n;
    switch (command)
    {
    case 1:
        n =10;
        m=11;
        break;
    case 2:
        n= 8;
        m =10;
        break;
    case 3:
        n=5;
        m=8;
        break;
    default:
        break;
    }
    for (i = 0; i < n; ++i)
        {
            for (j = 0; j < m; ++j)
            {
                if (map[i][j] == '@')
                {
                    location.packman.x = j;
                    location.packman.y = i;
                }

                if (map[i][j] == 'G')
                {
                    if (location.ghost[z].is_valid == 0 && z < ghost_max)
                    {
                        location.ghost[z].x = j;
                        location.ghost[z].y = i;
                        location.ghost[z].is_valid = 1;
                        ++z;
                    }
                }
            }
        }
}

void Move_Ghost()
{
    int i ,j, m, n;
    for(i =0 ; i< ghost_max ;++i)
    {
        if(location.ghost[i].is_valid == 1)
        {
            n = location.ghost[i].x;
            m = location.ghost[i].y;
            if(location.ghost[i].x > location.packman.x && (map[m][n-1]=='.'|| map[m][n-1] == '@'))
            {
                map[m][n-1] = 'G';
                map[m][n] = '.';
                location.ghost[i].x = n-1;
                location.ghost[i].y = m;
            }
            else if (location.ghost[i].x < location.packman.x && (map[m][n+1] == '.' || map[m][n+1] == '@'))
            {
                map[m][n+1] ='G';
                map[m][n] = '.';
                location.ghost[i].x = n+1;
                location.ghost[i].y = m;
            }
            else if (location.ghost[i].y > location.packman.y && (map[m-1][n] == '.'|| map[m-1][n] == '@'))
            {
                map[m-1][n] ='G';
                map[m][n] ='.';
                location.ghost[i].x = n;
                location.ghost[i].y = m-1;
            }
            else if (location.ghost[i].y < location.packman.y && (map[m+1][n] == '.'|| map[m+1][n] == '@'))
            {
                map[m+1][n] = 'G';
                map[m][n] ='.';
                location.ghost[i].x =n;
                location.ghost[i].y = m+1;
            }
            
            
            
        }
    }
}


