#include "projectpackman.h"

int main()
{
    int command , Counter , i;
    for(i=0 ; i < users_num ; ++i)
    {
        player[i].is_valid = 0;
        player[i].Status = 0;
        player[i].score =0;
        player[i].level= 0;
    }
    Read_fromfile();
    Counter = login();
    printf("Please select the game difficulty. Enter 1 for hard, 2 for medium, and 3 for easy.\n");
    scanf("%d", &command);
    setup(command , Counter);
    draw(command , Counter);  
    while (true)
    {
        find(command);
        input();
        logic(command, Counter);
        Move_Ghost();
        big_map(command);
        draw1(command , Counter);  
        Sleep(50);
    }
}