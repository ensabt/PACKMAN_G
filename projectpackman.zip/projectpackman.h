#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <Windows.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>

#define constant 50
#define ghost_max 2
#define users_num 1000
struct point
{
    int x, y;
    bool is_valid;
};

struct map
{
    struct point ghost[ghost_max];
    struct point PILL;
    struct point packman;
} location;

struct user
{
    char gamername[constant];
    char password[constant];
    char Filename[constant];
    int level;
    int score;
    int is_valid; // 1 f0r true 0 for false
    int Status; // 1 for true 0 for false
    int id;
    int difmap; //1 hardmap 2 intermediatmap 3 easy
    
};

int login();
void setup(int , int);
void draw(int , int);
void find(int);
void input();
void logic(int , int);
void Move_Ghost();
void draw1(int, int);
int creat_account(char[constant] , char [constant]);
char** big_map(int);
void Save_playerdata(int);
void Read_fromfile();
void delete_account(int);

char **map;
char** mapB;
struct user  player[users_num];
enum direction { STOP = 0, LEFT, RIGHT, UP, DOWN , EXIT};
enum direction dir;